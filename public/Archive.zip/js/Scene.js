var Scene = function(){
    this.width = 0;
    this.height = 0;
    this.ctx = null;
};

Scene.prototype.update = function(delta){

}

Scene.prototype.onTouchDown = function(x,y){
}

Scene.prototype.onKeyDown = function(key){
}
