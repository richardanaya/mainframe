var TestScene = function(game){
    this.game = game;
    this.infoText = [];
    this.time = 0;
    this.player = new Player();
    this.currentHeight = 1000
    this.mode = "play";
    this.showInfoText("You awake");
    this.size = 64;

    this.viewTranslateX = 0;
    this.viewTranslateY = 0;
    this.viewScaleX = 1;
    this.viewScaleY = 1;

    var _this = this;
    Hammer($('#screen').get(0)).on("dragstart", function(e) {
        _this.viewTranslateStartX = _this.viewTranslateX;
        _this.viewTranslateStartY = _this.viewTranslateY;
    });

    $('#screen').on('mousewheel', function(event) {
        var scaleStep = 1.5;
        var x = event.offsetX;
        var y = event.offsetY;
        if(event.deltaY>0){

            var mx = Math.floor((x-_this.viewTranslateX)/_this.viewScaleX);
            var my = Math.floor((y-_this.viewTranslateY)/_this.viewScaleY);
            _this.viewScaleX *= scaleStep;
            _this.viewScaleY *= scaleStep;
            var mxpost = Math.floor((x-_this.viewTranslateX)/_this.viewScaleX);
            var mypost = Math.floor((y-_this.viewTranslateY)/_this.viewScaleY);
            _this.viewTranslateX -= (mx-mxpost)*_this.viewScaleX;
            _this.viewTranslateY -= (my-mypost)*_this.viewScaleY;
        }
        else {
            var mx = Math.floor((x-_this.viewTranslateX)/_this.viewScaleX);
            var my = Math.floor((y-_this.viewTranslateY)/_this.viewScaleY);
            _this.viewScaleX /=scaleStep;
            _this.viewScaleY /=scaleStep;
            var mxpost = Math.floor((x-_this.viewTranslateX)/_this.viewScaleX);
            var mypost = Math.floor((y-_this.viewTranslateY)/_this.viewScaleY);
            _this.viewTranslateX -= (mx-mxpost)*_this.viewScaleX;
            _this.viewTranslateY -= (my-mypost)*_this.viewScaleY;
        }
    });

    Hammer($('#screen').get(0)).on("drag", function(e) {
        _this.viewTranslateX = _this.viewTranslateStartX+e.gesture.deltaX;
        _this.viewTranslateY = _this.viewTranslateStartY+e.gesture.deltaY;
    });

    this.pickupButton = new Button(this,0,100);
    this.pickupButton.visible = false;
    this.attackButton = new Button(this,0,220,"red");
    this.attackButton.visible = false;
    this.inventoryButton = new Button(this,0,0);
    this.inventoryButton.image = Resources.getImage("inventory");


    this.inventoryDialog = new InventoryDialog(this);
    this.inventoryDialog.scene = this;

    this.loadLevel(this.currentHeight)
};

TestScene.prototype = Object.create(Scene.prototype);

TestScene.prototype.loadLevel = function(height){
    var _this = this;
    if(_this.music){
        _this.music.fade(1,0,3000);
    }

    var done = function(){
        _this.game.changeScene(_this);
        _this.player.stopAutoMove();
        _this.level = _this.game.GetLevel(height);

        _this.level.addObjectTo( _this.level.center.x, _this.level.center.y, _this.player );
        _this.player.explore();

        _this.centerViewAroundPlayer();
        _this.level.scene = _this;
        _this.currentHeight = height;


        if(height == 1000){
            _this.music = new Howl({
                urls: ['sounds/rain.mp3'],
                loop: true
            }).play();
            _this.music.fade(0,1,3000);
            if(Flags.flag("intro")){
                _this.showDialog("You wake up to the sound of rain.  What happened? You feel a burning at the ache of your neck. You reach back and find blood at your neckport, but you cannot recall any memory how you arrived to the top of _this building.",_this.player.image_idle_0,_this.player.image_idle_1)
            }
        }
        else {
            _this.music = null;
        }
    }

    if(height == 1000){
        done();
    }
    else {
        this.game.changeScene(new ElevatorScene(this.game,done,this.currentHeight,height,this.player.image_idle_0))
    }
};

TestScene.prototype.centerViewAroundPlayer = function(){
    this.centerViewAroundSquare(this.player.x,this.player.y);
}

TestScene.prototype.centerViewAroundSquare = function(x,y){
    this.viewTranslateX = (-x*this.size-this.size/2)*this.viewScaleX+window.innerWidth/2;
    this.viewTranslateY = (-y*this.size-this.size/2)*this.viewScaleY+window.innerHeight/2;
}

TestScene.prototype.update = function(delta){
    this.time += delta;
    this.ctx.save();
    this.ctx.translate(this.viewTranslateX,this.viewTranslateY);
    this.ctx.scale(this.viewScaleX,this.viewScaleY);
    for(var x = 0; x < this.level.width; x++){
        for(var y = 0; y < this.level.width; y++){
            var t = this.level.tiles[this.level.width*y+x];
			if( t != null && t != undefined && t.image != undefined && t.image != null && t.explored ) {
            	this.ctx.drawImage(t.image,x*this.size ,y*this.size,this.size ,this.size  );
                if( t.room != null && t.room != undefined && t.room != this.player.activeRoom ) {
                    this.ctx.drawImage(Resources.getImage('fowoverlay'),x*this.size ,y*this.size,this.size ,this.size  );
                }
            	for(var i = 0 ; i < t.objects.length; i++){
            	    var o = t.objects[i];
            	    o.update(delta);
            	    this.ctx.save();
            	    if(o.flipped){
            	        this.ctx.translate(this.size* o.x+this.size,this.size* o.y);
            	        this.ctx.scale(-this.size,this.size);
            	    }
            	    else {
            	        this.ctx.translate(this.size* o.x,this.size* o.y);
            	        this.ctx.scale(this.size,this.size);
            	    }
            	    this.ctx.drawImage(o.image,0,0,1,1);
            	    this.ctx.restore();
				}
            }
        }
    }
    this.ctx.restore();

    this.pickupButton.update(delta);
    this.pickupButton.render();
    this.pickupButton.x = this.width-this.attackButton.width-10;
    this.attackButton.update(delta);
    this.attackButton.render();
    this.attackButton.x = this.width-this.attackButton.width-10;
    this.inventoryButton.x = this.width-this.attackButton.width-10;
    this.inventoryButton.y = this.height-this.attackButton.height-50;
    this.inventoryButton.render();


    this.ctx.font = "16px 'Press Start 2P'";
    this.ctx.fillStyle = "white";

    for(var i = 0 ; i < this.infoText.length ; i++){
        this.ctx.fillText(this.infoText[i].text,10, this.height-20*i-15);
    }

    if(this.mode == "dialog"){
        this.dialog.update(delta);
        this.dialog.render();
    }

    if(this.mode == "inventory"){
        this.inventoryDialog.update(delta);
        this.inventoryDialog.render();
    }
};

TestScene.prototype.processAllMoves = function(){
    var moves = [];
    for(var i = 0 ; i < this.level.allObjects.length; i++){
        if(this.level.allObjects[i].thinks){
            moves = moves.concat(this.level.allObjects[i].think());
        }
    }
    var _this = this;

    var i = 0;
    var process = function(i){
        if(i>= moves.length){
            //When done
            _this.centerViewAroundPlayer();
            var options_changed = _this.listOptions();
            this.graph = _this.level.getGraph();
            if(_this.player.autoMove() && !options_changed){
                setTimeout(function(){
                    _this.processAllMoves();
                },100);
            }
            return;
        }
        moves[i].process(function(){process(i+1);});
    }
    process(0);
}


TestScene.prototype.listOptions = function(){
    var options_changed = false;
    var pickup_targets = this.level.getObjectsByTypeOnTile(this.player.x,this.player.y,"item");
    if(pickup_targets.length>0){
        if(pickup_targets[0].id && Pickupable.Items[pickup_targets[0].id].floor_name){
            this.showInfoText("You are standing by a "+Pickupable.Items[pickup_targets[0].id].floor_name);
        }
        else {
            this.showInfoText("You are standing by something");
        }

        if(this.pickup_target != pickup_targets[0]){ options_changed = true;}
        this.pickup_target = pickup_targets[0];
        this.pickupButton.image = this.pickup_target.image;
        this.pickupButton.show();
    }
    else {
        this.pickupButton.hide();
        this.pickup_target = null;
    }
    var attack_targets = this.level.getNeighborObjectsByType(this.player.x,this.player.y,"monster");
    if(attack_targets.length>0){
        this.showInfoText("There's a monster nearby you can attack");
        if(this.attack_target != attack_targets[0]){ options_changed = true;}
        this.attack_target = attack_targets[0];
        this.attackButton.image = this.attack_target.image;
        this.attackButton.show();
    }
    else {
        this.attackButton.hide();
        this.attack_target = null;
    }
    return options_changed;
}


TestScene.prototype.onKeyDown = function(key){
    if(this.mode == "play"){
        this.graph = this.level.getGraph();
        if(key == 37){
            this.player.moveLeft();
        }
        else if(key == 38){
            this.player.moveUp();
        }
        else if(key == 39){
            this.player.moveRight();
        }
        else if(key == 40){
            this.player.moveDown();
        }
        this.processAllMoves();
    }
    else if(this.mode == "dialog"){
        this.mode = "play";
    }
};


TestScene.prototype.onTap = function(x,y){
    if(this.mode == "play"){
        this.graph = this.level.getGraph();
        var moveToX = Math.floor((x-this.viewTranslateX)/this.viewScaleX/this.size);
        var moveToY = Math.floor((y-this.viewTranslateY)/this.viewScaleY/this.size);


        if(this.pickup_target){
            if(this.pickupButton.isWithin(x,y)){
                this.player.pickup(this.pickup_target);
                this.processAllMoves();
                return;
            }
        }

        if(this.attack_target){
            if(this.attackButton.isWithin(x,y)){
                this.player.attack(this.attack_target);
                this.processAllMoves();
                return;
            }
        }

        if(this.inventoryButton.isWithin(x,y)){
            if(this.inventoryDialog.visible){
                this.inventoryDialog.hide();
                this.mode = "play";
                return;
            }
            else {
                this.mode = "inventory";
                this.inventoryDialog.show();
                return;
            }
        }

        if(this.level.isPointWithin(moveToX,moveToY)){
            this.player.autoMoveTo(Math.floor(moveToX),Math.floor(moveToY));
            this.player.autoMove();
            this.processAllMoves();
            return;
        }
    }
    else if(this.mode == "dialog"){
        this.mode = "play";
    }
    else if(this.mode == "inventory"){
        if(this.inventoryButton.isWithin(x,y)){
            if(this.inventoryDialog.visible){
                this.inventoryDialog.hide();
                this.mode = "play";
            }
        }
        this.inventoryDialog.onTap(x,y);
    }
}

TestScene.prototype.showDialog = function(text, img0, img1){
    this.mode = "dialog";
    this.dialog = new Dialog(this,text.toUpperCase());
    this.dialog.image = img0;
    this.dialog.imageAnim = img1;
    this.dialog.show();
    this.dialog.scene = this;
}


TestScene.prototype.showInfoText = function(text){
    this.infoText.push({text:text.toUpperCase(),time:this.time});
    if(this.infoText.length > 3){
        this.infoText.splice(0,1);
    }
}
